﻿CREATE TABLE [dbo].[Trainer] (
    [srno2]             INT           IDENTITY (1, 1) NOT NULL,
    [TrainerId]         NVARCHAR (50) NULL,
    [TrainerName]       NVARCHAR (50) NULL,
    [TrainerCourses]    NVARCHAR (50) NULL,
    [TrainerSalary]     NVARCHAR (50) NULL,
    [TrainerExperience] NCHAR (10)    NULL,
    PRIMARY KEY CLUSTERED ([srno2] ASC)
);

