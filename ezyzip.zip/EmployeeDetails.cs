﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FINALTRY
{
    public partial class EmployeeDetails : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");

        public EmployeeDetails()
        {
            InitializeComponent();
        }

        private void ApplyCourse_Load(object sender, EventArgs e)
        {

            GetEmployeeRecords();
            display();
        }

        private void GetEmployeeRecords()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("Select * from siddhi", con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FeedbackForm ob = new FeedbackForm();
            ob.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeLogin ob = new EmployeeLogin();
            ob.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlCommand c = new SqlCommand("Select * from siddhi", con);
            DataTable dt2 = new DataTable();

        }
        private void display()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");


            SqlCommand c = new SqlCommand("Select * from siddhi", con);
            DataTable dt2 = new DataTable();

            con.Open();

            SqlDataReader sdr2 = c.ExecuteReader();
            dt2.Load(sdr2);
            con.Close();

            dataGridView1.DataSource = dt2;
        }
    }
}
