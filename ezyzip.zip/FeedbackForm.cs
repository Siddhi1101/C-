﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace FINALTRY
{
    public partial class FeedbackForm : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");

        public FeedbackForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FeedbackForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (IsValid())
            {
                SqlCommand c = new SqlCommand("INSERT INTO Feedback VALUES(@SelectExperience,@OtherCourse,@WriteExperience) ", con);
                c.CommandType = CommandType.Text;
                c.Parameters.AddWithValue("@SelectExperience", comboBox1.SelectedItem);
                c.Parameters.AddWithValue("@OtherCourse", comboBox2.SelectedItem);
                c.Parameters.AddWithValue("@WriteExperience", textBox1.Text);
               


                con.Open();
                c.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Feedback given Successfully", "saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                


            }


        }

        private bool IsValid()
        {
            if (textBox1.Text == string.Empty)
            {
                MessageBox.Show("Please enter Feedback", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
    }
    }

