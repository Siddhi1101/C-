﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;


namespace FINALTRY
{
    public partial class Form1 : Form
    {


      SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");
        public int srno;

        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

            if(IsValid())
            {
                SqlCommand c = new SqlCommand("INSERT INTO siddhi VALUES(@EmployeeId,@EmployeeName,@EmployeePassword,@EmployeeNumber) ",con);
                c.CommandType = CommandType.Text;
               c.Parameters.AddWithValue("@EmployeeId",textBox1.Text);
                c.Parameters.AddWithValue("@EmployeeName", textBox4.Text);
                c.Parameters.AddWithValue("@EmployeePassword", textBox3.Text);
                c.Parameters.AddWithValue("@EmployeeNumber", textBox2.Text);

                con.Open();
                c.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("EMPLOYEE INSERTED SUCCESSFULLY","saved",MessageBoxButtons.OK,MessageBoxIcon.Information);

               GetEmployeeRecords();
            }
            

            con.Open();
            SqlCommand cmd = con.CreateCommand();
           // cmd.CommandType = CommandType.Text();
            cmd.CommandText="insert into Table values('"+textBox1+"','"+textBox2+"','"+textBox3+"','"+textBox4+"')";
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Employee inserted successfully");
            




        }
        
        private bool IsValid()
        {
            if (textBox2.Text == string.Empty)
            {
                MessageBox.Show("enter employee name","Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        
        
        private void Form1_Load(object sender, EventArgs e)
        {
            GetEmployeeRecords();
           ResetForm();

        }
        
        

        private void GetEmployeeRecords()
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");


            SqlCommand cmd = new SqlCommand("Select * from siddhi",con);
            DataTable dt = new DataTable();

            con.Open();

            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();

            dataGridView1.DataSource = dt;
        }
        
        
        private void button3_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
        
        
        private void ResetForm()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
        
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            srno =Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[4].Value);


        }
        
        
        
        
        private void button2_Click(object sender, EventArgs e)
        {
            
             if(srno>0)
             {
                 SqlCommand c = new SqlCommand("UPDATE siddhi SET EmployeeId=@EmployeeId,EmployeeName=@EmployeeName,EmployeeEmail=@EmployeeEmail,EmployeeNumber=@EmployeeNumber WHERE srno=@ID ", con);
                 c.CommandType = CommandType.Text;
                c.Parameters.AddWithValue("@ID", this.srno);
                c.Parameters.AddWithValue("@EmployeeId", textBox1.Text);
                 c.Parameters.AddWithValue("@EmployeeName", textBox2.Text);
                 c.Parameters.AddWithValue("@EmployeePassword", textBox3.Text);
                 c.Parameters.AddWithValue("@EmployeeNumber", textBox4.Text);
                

                con.Open();
                 c.ExecuteNonQuery();
                 con.Close();

                 MessageBox.Show("EMPLOYEE INFO UpdateD", "updated", MessageBoxButtons.OK, MessageBoxIcon.Information);

                 GetEmployeeRecords();
             }
            else
            {
                MessageBox.Show("Please select the employee", "select?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(srno>0)
            {

                SqlCommand c = new SqlCommand("DELETE FROM siddhi WHERE srno=@ID ", con);
                c.CommandType = CommandType.Text;
                c.Parameters.AddWithValue("@ID", this.srno);
               

                con.Open();
                c.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Employee deleted success", "deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetEmployeeRecords();

            }
            else
            {
                MessageBox.Show("Please select the employee", "select?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChoiceEmployeeTrainer ob = new ChoiceEmployeeTrainer();
            ob.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainingProgram ob = new TrainingProgram();
            ob.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (srno > 0)
            {

                SqlCommand c = new SqlCommand();
                c.CommandType = CommandType.Text;
                c.Parameters.AddWithValue("@ID", this.srno);
                this.Hide();
                EmployeeDetails ob = new EmployeeDetails();
                ob.Show();
                

              //  con.Open();
                //c.ExecuteNonQuery();
                //con.Close();

                //MessageBox.Show("Employee deleted", "deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetEmployeeRecords();

            }
            else
            {
                MessageBox.Show("Please select the Employee", "select?", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }



        }
    }
}
