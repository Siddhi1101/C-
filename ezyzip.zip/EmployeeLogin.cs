﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FINALTRY
{
    public partial class EmployeeLogin : Form
    {
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con3 = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");
            SqlDataAdapter sda= new SqlDataAdapter("Select Count(*) from siddhi where EmployeeId='"+textBox1.Text+"'and EmployeePassword='"+textBox2.Text+"'",con3);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1")
            {
                this.Hide();
                EmployeeDetails ob = new EmployeeDetails();
                ob.Show();

            }
            else
            {
                MessageBox.Show("Enter proper Id or Password");
            }


        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            login ob = new login();
            ob.Show();
        }
    }
}
