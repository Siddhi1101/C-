﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FINALTRY
{
    public partial class TrainingProgram : Form
    {
        SqlConnection con2 = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");

        public TrainingProgram()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            SqlCommand c = new SqlCommand("Select * from Trainer", con2);
            DataTable dt2 = new DataTable();

            


        }
        private void display()
        {
            SqlConnection con2 = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");


            SqlCommand c = new SqlCommand("Select * from Trainer", con2);
            DataTable dt2 = new DataTable();

            con2.Open();

            SqlDataReader sdr2 = c.ExecuteReader();
            dt2.Load(sdr2);
            con2.Close();

            
       dataGridView1.DataSource = dt2;
//            dataGridView1_CellClick.DataSource = dt2;
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TrainingProgram_Load(object sender, EventArgs e)
        {
            GetTrainerDetails();
            display();
        }

        private void GetTrainerDetails()
        {
            SqlConnection con2 = new SqlConnection(@"Data Source=DESKTOP-U9PA78D\MSSQLSERVER01;Initial Catalog=FinalDatabase;Integrated Security=True");


            SqlCommand c = new SqlCommand("Select * from Trainer", con2);
            DataTable dt2 = new DataTable();

            con2.Open();

            SqlDataReader sdr2 = c.ExecuteReader();
            dt2.Load(sdr2);
            con2.Close();

            //dataGridView1.Datasource = dt2;
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrainerLogin ob = new TrainerLogin();
            ob.Show();
        }
    }
}
